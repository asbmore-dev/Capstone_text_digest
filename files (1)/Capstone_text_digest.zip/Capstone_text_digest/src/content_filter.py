"""
content_filter.py
Checks digest text for inappropriate language using better-profanity.
"""

from __future__ import annotations

from better_profanity import profanity

# Load the default word list (can be extended)
profanity.load_censor_words()


def is_clean(text: str) -> bool:
    """Return True if the text contains no profanity."""
    return not profanity.contains_profanity(text)


def sanitize(text: str) -> str:
    """Replace profane words with '***'."""
    return profanity.censor(text, censor_char="*")


def check_and_clean(text: str) -> tuple[bool, str]:
    """
    Inspect the digest for inappropriate language.

    Returns:
        (is_safe, processed_text)
        - is_safe=True  → text was clean, returned as-is
        - is_safe=False → text was sanitized, caller should warn user
    """
    if is_clean(text):
        return True, text

    cleaned = sanitize(text)
    return False, cleaned


def add_custom_words(words: list[str]) -> None:
    """Extend the profanity list with custom words."""
    profanity.add_censor_words(words)
