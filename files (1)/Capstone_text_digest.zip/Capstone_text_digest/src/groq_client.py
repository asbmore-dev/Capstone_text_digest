"""
groq_client.py
Wrapper around the Groq free API for text summarization with style adaptation.
"""

from __future__ import annotations

from groq import Groq


# ── Prompt builder ─────────────────────────────────────────────────────────────

STYLE_INSTRUCTIONS: dict[str, str] = {
    "original": "Preserve the author's original voice and tone as closely as possible.",
    "modern": "Use contemporary, accessible language suitable for a general audience today.",
    "humorous": "Add light wit and humor while still conveying the core information accurately.",
    "professional": "Use formal, business-appropriate language. Be precise and concise.",
    "academic": "Use scholarly language with precise terminology. Maintain an objective tone.",
    "casual": "Write in a friendly, conversational tone as if explaining to a friend.",
}


def build_prompt(title: str, body: str, style: str) -> str:
    """Construct the summarization prompt."""
    style_instruction = STYLE_INSTRUCTIONS.get(
        style.lower(),
        f"Write in a {style} style.",
    )

    return f"""You are an expert text summarizer and editor.

Your task is to create a concise digest (summary) of the text provided below.

STYLE REQUIREMENT: {style_instruction}

RULES:
- Reduce the text to approximately 25–35% of its original length.
- Preserve all key facts, arguments, and conclusions.
- Do NOT use foul language, slurs, or inappropriate content under any circumstances.
- Do NOT include the title in your response — only the digest body.
- Output ONLY the digest text, no preamble or commentary.

TITLE: {title}

ORIGINAL TEXT:
{body[:12000]}
"""


# ── Main summarizer ────────────────────────────────────────────────────────────

def summarize(title: str, body: str, style: str, api_key: str) -> str:
    """
    Call Groq LLaMA-3.1-8B-Instant to summarize text with a chosen style.

    Args:
        title:   Detected title of the source document.
        body:    Main text content (will be truncated to 12k chars if needed).
        style:   Style keyword or custom string.
        api_key: Groq API key.

    Returns:
        Digest string.
    """
    client = Groq(api_key=api_key)
    prompt = build_prompt(title, body, style)

    response = client.chat.completions.create(
        model="llama-3.1-8b-instant",  # free tier
        messages=[
            {
                "role": "system",
                "content": (
                    "You are a professional text summarizer. "
                    "Always produce clean, appropriate, well-written output."
                ),
            },
            {"role": "user", "content": prompt},
        ],
        temperature=0.6,
        max_tokens=1024,
    )

    return response.choices[0].message.content.strip()


def safe_retry_summarize(title: str, body: str, api_key: str) -> str:
    """
    Fallback: re-request a clean, professional summary when content filter fails.
    Uses 'professional' style to minimize risk of inappropriate output.
    """
    return summarize(title, body, "professional", api_key)
