"""
input_handler.py
Parses input from .txt, .pdf, .doc/.docx, .rtf, or HTTP URL.
Returns (title: str, body: str).
"""

from __future__ import annotations

import io
import re
import urllib.request
from pathlib import Path
from typing import Union

import requests
from bs4 import BeautifulSoup


# ── Public router ─────────────────────────────────────────────────────────────

def parse_input(source) -> tuple[str, str]:
    """
    Route to the correct extractor.

    Args:
        source: Streamlit UploadedFile  OR  a URL string.

    Returns:
        (title, body) tuple of strings.
    """
    if isinstance(source, str):
        return extract_from_url(source)

    name = source.name.lower()
    data = source.read()

    if name.endswith(".txt"):
        return extract_from_txt(data)
    elif name.endswith(".pdf"):
        return extract_from_pdf(data)
    elif name.endswith((".docx", ".doc")):
        return extract_from_docx(data)
    elif name.endswith(".rtf"):
        return extract_from_rtf(data)
    else:
        raise ValueError(f"Unsupported file type: {name}")


# ── Extractors ────────────────────────────────────────────────────────────────

def extract_from_txt(data: bytes) -> tuple[str, str]:
    """Read UTF-8 plain text file."""
    text = data.decode("utf-8", errors="replace")
    return _split_title_body(text)


def extract_from_pdf(data: bytes) -> tuple[str, str]:
    """Extract text from PDF using PyMuPDF (fitz)."""
    try:
        import fitz  # PyMuPDF
    except ImportError:
        raise ImportError("Install PyMuPDF: uv add pymupdf")

    doc = fitz.open(stream=data, filetype="pdf")
    pages = [page.get_text() for page in doc]
    full_text = "\n".join(pages)
    return _split_title_body(full_text)


def extract_from_docx(data: bytes) -> tuple[str, str]:
    """Extract text from .docx using python-docx."""
    try:
        from docx import Document
    except ImportError:
        raise ImportError("Install python-docx: uv add python-docx")

    doc = Document(io.BytesIO(data))
    paragraphs = [p.text for p in doc.paragraphs if p.text.strip()]
    full_text = "\n".join(paragraphs)
    return _split_title_body(full_text)


def extract_from_rtf(data: bytes) -> tuple[str, str]:
    """Strip RTF control words and extract plain text."""
    try:
        from striprtf.striprtf import rtf_to_text
    except ImportError:
        raise ImportError("Install striprtf: uv add striprtf")

    rtf_string = data.decode("latin-1", errors="replace")
    plain = rtf_to_text(rtf_string)
    return _split_title_body(plain)


def extract_from_url(url: str) -> tuple[str, str]:
    """Scrape visible text from a web page."""
    headers = {"User-Agent": "Mozilla/5.0 (compatible; TextDigestBot/1.0)"}
    resp = requests.get(url, headers=headers, timeout=15)
    resp.raise_for_status()

    soup = BeautifulSoup(resp.text, "lxml")

    # Remove script / style noise
    for tag in soup(["script", "style", "nav", "footer", "header"]):
        tag.decompose()

    # Try to find an <h1> for the title
    h1 = soup.find("h1")
    title = h1.get_text(strip=True) if h1 else ""

    # Collect <p> body text
    paragraphs = [p.get_text(separator=" ", strip=True) for p in soup.find_all("p")]
    body = "\n".join(p for p in paragraphs if len(p) > 40)

    if not title:
        title = detect_title(body)

    return title, body


# ── Helpers ───────────────────────────────────────────────────────────────────

def detect_title(text: str) -> str:
    """Return the first non-empty line as the title."""
    for line in text.splitlines():
        stripped = line.strip()
        if stripped:
            return stripped[:120]  # cap at 120 chars
    return "Untitled"


def _split_title_body(text: str) -> tuple[str, str]:
    """First non-empty line becomes the title; rest is body."""
    lines = text.splitlines()
    title = ""
    body_start = 0

    for i, line in enumerate(lines):
        if line.strip():
            title = line.strip()[:120]
            body_start = i + 1
            break

    body = "\n".join(lines[body_start:]).strip()
    return title or "Untitled", body
