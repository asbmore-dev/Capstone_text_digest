"""
Capstone_text_digest — app.py
Streamlit entry point
"""

import os
import tempfile
from pathlib import Path

import streamlit as st
from dotenv import load_dotenv

from input_handler import parse_input
from groq_client import summarize
from content_filter import check_and_clean
from output_writer import write_output
from tts_engine import get_audio_bytes

load_dotenv()

# ── Page config ──────────────────────────────────────────────────────────────
st.set_page_config(
    page_title="Capstone Text Digest",
    page_icon="📄",
    layout="wide",
)

st.title("📄 Capstone Text Digest")
st.caption("Transform any text into a polished, styled summary using Groq AI.")

# ── Sidebar ───────────────────────────────────────────────────────────────────
with st.sidebar:
    st.header("⚙️ Settings")

    api_key = st.text_input(
        "Groq API Key",
        value=os.getenv("GROQ_API_KEY", ""),
        type="password",
        help="Get a free key at https://console.groq.com",
    )

    st.divider()

    PRESET_STYLES = ["original", "modern", "humorous", "professional", "academic", "casual"]
    style_preset = st.selectbox("Output Style (preset)", PRESET_STYLES)
    custom_style = st.text_input("Or type a custom style", placeholder="e.g. pirate, Hemingway, Gen-Z")
    chosen_style = custom_style.strip() if custom_style.strip() else style_preset

    st.divider()

    output_format = st.selectbox(
        "Output Format",
        ["txt", "pdf", "docx", "rtf", "html"],
    )

    voice_reading = st.toggle("🔊 Enable Voice Reading", value=False)

    st.divider()
    st.markdown("**Model:** `llama-3.1-8b-instant` (free)")
    st.markdown("**TTS:** Google Text-to-Speech (free)")

# ── Input area ────────────────────────────────────────────────────────────────
col1, col2 = st.columns([1, 1], gap="large")

with col1:
    st.subheader("📥 Input Source")
    input_mode = st.radio("Choose input mode", ["Upload File", "Enter URL"], horizontal=True)

    uploaded_file = None
    url_input = ""

    if input_mode == "Upload File":
        uploaded_file = st.file_uploader(
            "Upload your document",
            type=["txt", "pdf", "doc", "docx", "rtf"],
            help="Supported: .txt · .pdf · .doc · .docx · .rtf",
        )
    else:
        url_input = st.text_input(
            "Enter a URL",
            placeholder="https://en.wikipedia.org/wiki/...",
        )

with col2:
    st.subheader("📤 Output Preview")
    result_placeholder = st.empty()

# ── Process button ────────────────────────────────────────────────────────────
st.divider()
run_btn = st.button("✨ Generate Digest", type="primary", use_container_width=True)

if run_btn:
    # Validation
    if not api_key:
        st.error("Please enter your Groq API key in the sidebar.")
        st.stop()

    source = uploaded_file if input_mode == "Upload File" else url_input.strip()
    if not source:
        st.error("Please provide a file or URL.")
        st.stop()

    # ── Step 1: Extract text ──────────────────────────────────────────────────
    with st.spinner("📖 Extracting text from source…"):
        try:
            title, body = parse_input(source)
        except Exception as exc:
            st.error(f"Could not extract text: {exc}")
            st.stop()

    st.info(f"**Detected title:** {title}")

    # ── Step 2: Summarize via Groq ────────────────────────────────────────────
    with st.spinner(f"🤖 Generating {chosen_style} digest via Groq AI…"):
        try:
            raw_digest = summarize(title, body, chosen_style, api_key)
        except Exception as exc:
            st.error(f"Groq API error: {exc}")
            st.stop()

    # ── Step 3: Content filter ────────────────────────────────────────────────
    with st.spinner("🔍 Checking content safety…"):
        is_safe, digest = check_and_clean(raw_digest)

    if not is_safe:
        st.warning("⚠️ Some content was filtered for inappropriate language.")

    # ── Step 4: Build final text ──────────────────────────────────────────────
    header_line1 = title
    header_line2 = f"Style: {chosen_style.title()}"
    full_text = f"{header_line1}\n{header_line2}\n\n{digest}"

    # ── Step 5: Show preview ──────────────────────────────────────────────────
    with result_placeholder.container():
        st.text_area("Digest Preview", full_text, height=350)

    # ── Step 6: Write output file ─────────────────────────────────────────────
    with st.spinner(f"💾 Writing {output_format.upper()} file…"):
        try:
            out_path = write_output(header_line1, header_line2, digest, output_format)
        except Exception as exc:
            st.error(f"Could not write output file: {exc}")
            st.stop()

    with open(out_path, "rb") as f:
        file_bytes = f.read()

    st.download_button(
        label=f"⬇️ Download {output_format.upper()} Digest",
        data=file_bytes,
        file_name=Path(out_path).name,
        mime=_mime_for(output_format),
        use_container_width=True,
    )

    # ── Step 7: Voice reading ─────────────────────────────────────────────────
    if voice_reading:
        with st.spinner("🔊 Generating audio…"):
            try:
                audio_bytes = get_audio_bytes(full_text)
                st.audio(audio_bytes, format="audio/mp3")
                st.download_button(
                    "⬇️ Download MP3",
                    data=audio_bytes,
                    file_name="digest_audio.mp3",
                    mime="audio/mpeg",
                )
            except Exception as exc:
                st.warning(f"Voice generation failed: {exc}")

    st.success("✅ Digest complete!")


def _mime_for(fmt: str) -> str:
    return {
        "txt": "text/plain",
        "pdf": "application/pdf",
        "docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        "rtf": "application/rtf",
        "html": "text/html",
    }.get(fmt, "application/octet-stream")
