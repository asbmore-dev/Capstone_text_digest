"""
tts_engine.py
Text-to-Speech using Google Text-to-Speech (gTTS) — free, no API key required.
Returns MP3 bytes suitable for Streamlit st.audio().
"""

from __future__ import annotations

import io


def text_to_speech(text: str, lang: str = "en", slow: bool = False) -> bytes:
    """
    Convert text to MP3 audio bytes using gTTS.

    Args:
        text: The text to convert to speech.
        lang: BCP-47 language code (default: 'en').
        slow: If True, speak slowly (useful for language learning).

    Returns:
        MP3 audio as bytes.
    """
    try:
        from gtts import gTTS
    except ImportError:
        raise ImportError("Install gTTS: uv add gtts")

    # gTTS has a ~5000 char per request soft limit; chunk if needed
    chunks = _chunk_text(text, max_chars=4500)
    buffer = io.BytesIO()

    for chunk in chunks:
        tts = gTTS(text=chunk, lang=lang, slow=slow)
        tts.write_to_fp(buffer)

    return buffer.getvalue()


def get_audio_bytes(text: str, lang: str = "en") -> bytes:
    """
    Wrapper for Streamlit usage.
    Trims the text to a reasonable length for TTS (first 3000 chars).

    Args:
        text: Full digest text (including header lines).
        lang: Language code.

    Returns:
        MP3 bytes.
    """
    # Limit to keep TTS generation fast
    trimmed = text[:3000]
    if len(text) > 3000:
        trimmed += "\n\n[Audio trimmed for length. Full digest in the downloaded file.]"

    return text_to_speech(trimmed, lang=lang)


# ── Helpers ────────────────────────────────────────────────────────────────────

def _chunk_text(text: str, max_chars: int = 4500) -> list[str]:
    """Split text into chunks without breaking mid-sentence."""
    if len(text) <= max_chars:
        return [text]

    chunks: list[str] = []
    current = ""

    for sentence in text.replace("\n", " ").split(". "):
        candidate = current + sentence + ". "
        if len(candidate) <= max_chars:
            current = candidate
        else:
            if current:
                chunks.append(current.strip())
            current = sentence + ". "

    if current.strip():
        chunks.append(current.strip())

    return chunks or [text[:max_chars]]
